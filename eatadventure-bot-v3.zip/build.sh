#!/bin/bash

# eatadventure Bot - Build Script (Mac/Linux)

echo "🚀 eatadventure Bot - Build Script"
echo "=================================="
echo ""

# Check if gradlew exists
if [ ! -f "./gradlew" ]; then
    echo "❌ gradlew not found!"
    echo "Make sure you're in the eatadventure-bot directory"
    exit 1
fi

# Make gradlew executable
chmod +x ./gradlew

echo "📦 Building APK..."
echo ""

# Build
./gradlew assembleDebug

# Check if build successful
if [ -f "app/build/outputs/apk/debug/app-debug.apk" ]; then
    echo ""
    echo "✅ Build successful!"
    echo ""
    echo "📍 APK location:"
    echo "   app/build/outputs/apk/debug/app-debug.apk"
    echo ""
    echo "📱 Next steps:"
    echo "   1. Connect your Android device (USB Debugging ON)"
    echo "   2. Run: adb install app/build/outputs/apk/debug/app-debug.apk"
    echo "   3. Or copy APK to your phone manually"
    echo ""
    echo "🎮 Then:"
    echo "   1. Open eatadventure Bot app"
    echo "   2. Tap 🔧 Accessibility Service aktivieren"
    echo "   3. Enable in Settings → Bedienungshilfen"
    echo "   4. Tap ▶️ Start!"
    echo ""
else
    echo ""
    echo "❌ Build failed!"
    echo "Check error messages above"
    exit 1
fi
