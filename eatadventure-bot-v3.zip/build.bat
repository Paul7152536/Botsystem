@echo off

REM eatadventure Bot - Build Script (Windows)

echo 🚀 eatadventure Bot - Build Script
echo ==================================
echo.

REM Check if gradlew exists
if not exist "gradlew.bat" (
    echo ❌ gradlew.bat not found!
    echo Make sure you're in the eatadventure-bot directory
    exit /b 1
)

echo 📦 Building APK...
echo.

REM Build
call gradlew.bat assembleDebug

REM Check if build successful
if exist "app\build\outputs\apk\debug\app-debug.apk" (
    echo.
    echo ✅ Build successful!
    echo.
    echo 📍 APK location:
    echo    app\build\outputs\apk\debug\app-debug.apk
    echo.
    echo 📱 Next steps:
    echo    1. Connect your Android device (USB Debugging ON)
    echo    2. Run: adb install app\build\outputs\apk\debug\app-debug.apk
    echo    3. Or copy APK to your phone manually
    echo.
    echo 🎮 Then:
    echo    1. Open eatadventure Bot app
    echo    2. Tap 🔧 Accessibility Service aktivieren
    echo    3. Enable in Settings ^→ Bedienungshilfen
    echo    4. Tap ▶️ Start!
    echo.
) else (
    echo.
    echo ❌ Build failed!
    echo Check error messages above
    exit /b 1
)

pause
