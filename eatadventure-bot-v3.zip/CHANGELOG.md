# Changelog - eatadventure Bot

## [1.1.0] - 2026-09-30

### ✨ Features
- **Skip-Button Erkennung**: Bot erkennt automatisch "Skip" / "→" Pfeil und klickt ihn
- **Variable Video-Wartezeiten**: Unterstützt jetzt Videos bis 120 Sekunden
- **Intelligenteres Video-Handling**: Skip hat Priorität vor normalen Wartezeiten

### 🔧 Improvements
- Video-Wartezeit erhöht (45s → 120s max)
- Besseres Video-State Management
- Bessere Debug-Logs mit Emojis für bessere Lesbarkeit
- Skip-Button wird priorisiert erkannt

### 🐛 Bug Fixes
- Fixed: Video konnte zu früh abgebrochen werden

---

## [1.0.0] - 2026-09-30

### 🎉 Initial Release

### ✨ Features
- Accessibility Service für Android Automation
- Automatische Upgrade-Button Erkennung
- Video-Ad Watcher (45 Sekunden)
- Start/Stop UI in Android App
- Intelligente Verzögerungen zwischen Aktionen
- GitHub Actions für automatisches APK Building

### 📱 Supported
- Android 5.0+ (API 21+)
- Kotlin Coroutines
- Timber Logging

---

## Geplante Features (TODO)

- [ ] Konfigurierbare Wartezeiten in Settings
- [ ] Button-Whitelist/Blacklist
- [ ] Anti-Ban Features (Randomisierte Delays)
- [ ] Statistik-Tracking (Upgrades pro Stunde, Videos geschaut)
- [ ] Multi-Account Support
- [ ] Web Dashboard für Monitoring
- [ ] Notification bei Upgrades/Videos
- [ ] Automatisches Backup der Stats

---

## Known Issues

- ⚠️ Skip-Button kann manchmal nicht erkannt werden wenn Text-Label fehlt
- ⚠️ Videos mit Custom-Ads können längere Wartezeiten brauchen (bis 120s)
- ⚠️ Auf einigen Devices können UI-Scans zu Lag führen

---

## Installation & Updates

Neue Versionen können einfach über GitHub Releases heruntergeladen werden:
https://github.com/paulgorner/eatadventure-bot/releases

Alte APK deinstallieren → Neue APK installieren = Automatisches Update ✨
