# 🤖 eatadventure Bot

Automatisierter Bot für das Mobile Game **eatadventure** - klickt automatisch Upgrades und schaut Videos für Boni.

## ⚠️ WICHTIG - DISCLAIMER

**DIESE APP VERSTÖSST GEGEN DIE NUTZUNGSBEDINGUNGEN VON EATADVENTURE!**

- ❌ Der Bot kann zum **Account-Ban** führen
- ❌ Nutze ihn NUR auf einem **Test-Account**
- ❌ Auf eigenes Risiko verwenden

## 🚀 Features

✅ Erkennt Upgrade-Buttons automatisch  
✅ Klickt verfügbare Upgrades  
✅ Schaut Video-Ads automatisch  
✅ Wartet intelligente Verzögerungen zwischen Aktionen  
✅ Läuft im Hintergrund via Accessibility Service  
✅ Einfache Start/Stop-Kontrolle in der App  

## 📱 Installation

### Voraussetzungen
- Android 5.0+ (API 21+)
- USB-Debugging aktiviert (optional)
- Unbekannte Quellen erlaubt

### Schritt 1: APK herunterladen

Gehe zu [Releases](https://github.com/paulgorner/eatadventure-bot/releases) und lade die neueste `app-debug.apk` herunter.

### Schritt 2: App installieren

```bash
# Wenn adb verfügbar ist:
adb install app-debug.apk

# Oder: Manuell auf Handy kopieren und öffnen
```

### Schritt 3: Permissions geben

1. Öffne die App
2. Klick auf **"🔧 Accessibility Service aktivieren"**
3. Gehe zu Settings → Accessibility → Accessibility Service
4. Finde "eatadventure Bot" und aktiviere es

### Schritt 4: Bot starten

1. Öffne **eatadventure** im Hintergrund
2. Öffne die **eatadventure Bot** App
3. Klick **"▶️ Automation starten"**
4. Der Bot läuft jetzt automatisch!

## 🔨 Selbst bauen (Developers)

### Voraussetzungen
- Android Studio
- JDK 11+
- Gradle

### Kompilieren

```bash
git clone https://github.com/paulgorner/eatadventure-bot.git
cd eatadventure-bot

# Debug APK bauen
./gradlew assembleDebug

# APK befindet sich dann in: app/build/outputs/apk/debug/app-debug.apk
```

### Mit GitHub Actions

Jeder Push zu `main` oder `master` baut automatisch die APK via GitHub Actions!

## 📋 Wie es funktioniert

Der Bot nutzt Android **Accessibility Services** um:

1. **UI durchsuchen** - Scannt die sichtbaren Elemente
2. **Buttons erkennen** - Sucht nach Upgrade/Video-Keywords
3. **Automatisch klicken** - Performt Click-Actions
4. **Warten** - Intelligente Verzögerungen (Videos: 45s, Upgrades: 800ms)
5. **Loop** - Wiederholt bis gestoppt

## ⚙️ Konfiguration

Momentan im Code hardcodiert. Könnte erweitert werden um:
- Custom Wartezeiten
- Video-Erkennungsschwelle
- Button-Whitelist/Blacklist

## 🐛 Debugging

Logs erscheinen in Logcat:
```bash
adb logcat | grep eatadventure
```

## 🤝 Wichtige Tipps

- 🔒 **Nur Test-Account** - Nutze einen separaten Account!
- 📊 **Monitoring** - Beobachte den Bot anfangs manuell
- ⏸️ **Pausen** - Gib dem Account Breaks, um natürlich zu wirken
- 🎯 **Realistisch** - Der Bot ist schnell, fügt künstliche Delays ein

## 📝 License

MIT - Aber beachte die oben erwähnte Warnung!

## 🙋 Support

Problem gefunden? [Öffne ein Issue](https://github.com/paulgorner/eatadventure-bot/issues)

---

**Viel Spaß mit dem Bot! Und denk dran: Mit großer Macht kommt große Verantwortung.** 🦸
