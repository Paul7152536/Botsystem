# ⚡ QUICK START - Bot Sofort Nutzen!

## 🎯 3 Optionen:

---

## Option 1️⃣: APK direkt bauen & installieren (EINFACHSTE)

### Voraussetzungen:
- ✅ Android Studio installiert (oder nur Android SDK)
- ✅ Handy mit USB-Debugging oder Emulator
- ✅ Dieses Projekt gecloned

### Schritt 1: APK bauen

**Terminal öffnen im Projekt-Ordner:**

```bash
cd /pfad/zum/eatadventure-bot

# Windows:
gradlew.bat assembleDebug

# Mac/Linux:
chmod +x gradlew
./gradlew assembleDebug
```

**Fertig! APK ist hier:** `app/build/outputs/apk/debug/app-debug.apk`

### Schritt 2: Auf Handy installieren

#### Mit USB-Debugging (schnell):
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

#### Ohne ADB (manuell):
1. APK-Datei auf Handy kopieren
2. Datei-Manager öffnen
3. APK antippen
4. Installation bestätigen
5. "Unbekannte Quellen" erlauben wenn gefragt

### Schritt 3: Accessibility Service aktivieren

1. **eatadventure Bot** App starten
2. Button **"🔧 Accessibility Service aktivieren"** klicken
3. In **Einstellungen → Bedienungshilfen** gehen
4. "eatadventure Bot" aktivieren
5. ✅ Fertig!

### Schritt 4: Bot starten

1. **eatadventure** Spiel öffnen (im Hintergrund)
2. **eatadventure Bot** App öffnen
3. **"▶️ Automation starten"** klicken
4. 🤖 Bot läuft! Zuschauen!

---

## Option 2️⃣: GitHub Push + Auto-Build (COOL)

### Voraussetzungen:
- ✅ GitHub Account
- ✅ Git installiert
- ✅ Dieses Projekt als Folder

### Schritt 1: GitHub Repo erstellen

```bash
# Auf github.com:
1. "New repository" klicken
2. Name: "eatadventure-bot"
3. Private oder Public
4. Create repository
```

### Schritt 2: Auf GitHub pushen

```bash
cd /pfad/zum/eatadventure-bot

# Remote hinzufügen
git remote add origin https://github.com/DEIN_USERNAME/eatadventure-bot.git
git branch -M main
git push -u origin main
```

### Schritt 3: GitHub Actions verwendet!

```
GitHub Actions baut AUTOMATISCH die APK!
Schau auf: GitHub → Actions → Build APK
Nach ein paar Minuten ist die APK ready!
```

### Schritt 4: APK runterladen

```
GitHub → Releases (wenn du einen Tag machst)
ODER
GitHub → Actions → Artifacts
→ app-debug.apk runterladen
→ Auf Handy installieren (wie Option 1)
```

---

## Option 3️⃣: Android Studio (Komfortabel)

### Schritt 1: Projekt öffnen
```
Android Studio starten
File → Open
Ordner "eatadventure-bot" wählen
```

### Schritt 2: Build & Run
```
Menu: Build → Build Bundle(s) / APK(s) → Build APK(s)
ODER
▶️ Run Button
```

### Schritt 3: APK installieren
```
Android Studio installiert automatisch auf Emulator/Handy!
```

---

## 🎮 Bot Konfigurieren

### In der App:

1. **⚙️ Einstellungen** Button klicken
2. **Optionen anpassen:**
   - 🛡️ Anti-Ban: ON (empfohlen)
   - 🎲 Random Delays: ON (empfohlen)
   - 🎬 Video Max: 120s (default)
   - ⏱️ Upgrade Delay: 800ms (default)
   - 🔍 Button Filter: OFF (wenn du alle Upgrades willst)
3. **💾 Speichern** klicken
4. Zurück zur Main Activity
5. **▶️ Start** drücken

---

## 📊 Statistics

Nach dem Bot läuft:

1. **⚙️ Einstellungen** öffnen
2. Scrolle unten zu "📊 Statistiken"
3. Sehe live:
   - ✅ Upgrades: X
   - 🎬 Videos: Y
   - ⏱️ Runtime: Z min
   - 🔄 Sessions: N

---

## 🆘 Troubleshooting

### Problem: "Service nicht aktiviert"
**Lösung:**
```
Einstellungen → Bedienungshilfen → eatadventure Bot → AN
```

### Problem: Bot macht nix
**Checklist:**
- [ ] Ist Service wirklich aktiviert? (Status ✅)
- [ ] Läuft eatadventure im Hintergrund?
- [ ] Handy nicht ins Ruhestand?
- [ ] Internet an?

### Problem: Build fehlt
```bash
# Clean + Rebuild:
./gradlew clean
./gradlew assembleDebug
```

### Problem: "Unknown APK format"
```
→ APK ist kaputt oder alte Version
→ Lösche app/build/ und rebuild
```

---

## 📱 Was passiert im Hintergrund?

```
🚀 START
   ↓
✅ Bot sucht Upgrade-Buttons
   ↓
   Falls ja → KLICK (mit Random Delay)
   Falls nein → Gehe zu Video
   ↓
🎬 Bot sucht Video-Buttons
   ↓
   Falls ja → KLICK Video
   Falls nein → Warte & Retry
   ↓
⏭️ Video läuft? Suche Skip-Button
   ↓
   Falls ja → KLICK Skip (sofort!)
   Falls nein → Warte 120-150s
   ↓
📊 Stats aufzeichnen
   ↓
🔄 Alles wiederholen
   ↓
⏹️ STOP Button → Beende Session
```

---

## 💡 Pro-Tipps

### Tipp 1: Anti-Ban aktiviert lassen!
```
Random Delays machen den Bot menschlich
→ Weniger Ban-Risiko
```

### Tipp 2: Nicht 24/7 laufen lassen!
```
Gib dem Account Pausen
→ Realistischer
→ Weniger verdächtig
```

### Tipp 3: Stats überwachen!
```
Checke regelmäßig:
- Sind Upgrades/Videos realistisch?
- Ist Runtime normal?
- Gibt's Fehler in Logs?
```

### Tipp 4: Logs anschauen!
```bash
# Real-time Logs sehen:
adb logcat | grep eatadventure

# Filter nur Errors:
adb logcat | grep "eatadventure.*E"
```

---

## ⚠️ WICHTIG!

```
🔴 NUR auf TEST-ACCOUNT verwenden!
🔴 Game kann Account bannen!
🔴 Nicht 24/7 laufen lassen!
🔴 Auf eigenes Risiko!
```

---

## ✅ Fertig?

Wenn du alles gemacht hast:

```
1. ✅ APK gebaut/installiert
2. ✅ Service aktiviert
3. ✅ Settings konfiguriert
4. ✅ Bot gestartet

→ Du bist fertig! Viel Spaß! 🎮
```

---

## 🆘 Noch Fragen?

Check:
- 📖 README.md (Übersicht)
- 📋 FEATURES.md (Was der Bot kann)
- 📝 INSTALLATION.md (Detailliert)
- 🔄 CHANGELOG.md (Version-History)

---

**Happy Botting!** 🤖✨
