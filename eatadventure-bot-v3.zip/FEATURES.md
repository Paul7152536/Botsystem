# 🚀 eatadventure Bot - Features

## Core Features

### 🤖 Automation
- ✅ Automatische Upgrade-Button Erkennung
- ✅ Video-Ads automatisch anschauen
- ✅ Skip-Button Erkennung und automatisches Klicken
- ✅ Intelligente Verzögerungen zwischen Aktionen

### 📱 Android Integration
- ✅ Accessibility Service für native UI-Automation
- ✅ Start/Stop Controls via Broadcast
- ✅ Background Service (läuft auch wenn App im Hintergrund)
- ✅ Nicht-invasiv (nutzt nur Accessibility APIs)

---

## 🛡️ Anti-Ban Features

### Randomisierte Delays
```
Upgrade-Clicks:   500-2000ms  (normal: 800ms)
Video-Wartezeit:  120-150s    (variabel)
UI-Scans:         1000-3000ms (normal: 2000ms)
Skip-Button:      300-800ms   (normal: sofort)
```

**Ziel**: Bot wirkt menschlicher und versteckt sich vor Anti-Cheat-Systemen

### Konfigurierbar
- An/Aus Schalter für Anti-Ban
- Randomisierte Delays aktivierbar
- Custom Verzögerungszeiten
- Base-Delays + Random-Offset

---

## 📊 Stats & Analytics

### Tracking
- ✅ Gesamte Upgrades (Session + Allzeit)
- ✅ Videos geschaut (Session + Allzeit)
- ✅ Runtime Tracking (in Minuten)
- ✅ Session Counter
- ✅ Letzte Session Zeit

### Persistent Storage
- Alle Stats werden lokal gespeichert (SharedPreferences)
- Überleben App-Neustarts
- Exportierbar über Logcat

---

## ⚙️ Configuration & Settings

### Video Settings
- 🎬 Max Video Wait Time (30-120s)
- 🎬 Skip-Button Auto-Detect
- 🎬 Variable Video-Längen Support

### Upgrade Settings
- ⏱️ Upgrade Delay (100-2000ms)
- ⏱️ Batch-Verarbeitung von Upgrades
- ⏱️ Konfigurierbar im Settings UI

### Button Filter
- 🔍 Whitelist: Nur bestimmte Buttons klicken
- 🔍 Blacklist: Bestimmte Buttons ignorieren
- 🔍 An/Aus Schalter
- 🔍 Filter-Manager in Settings

### System Settings
- 🚀 Auto-Start beim Booten (geplant)
- 💾 Config Persistierung
- 🔄 Reset-to-Defaults

---

## 🎮 Upgrade Recognition

Der Bot erkennt folgende Upgrade-Keywords:

### Deutsch
- "Echtes Hühnchen"
- "Verbesserte Hygiene"
- "Inline-Skates"
- "Bessere Handschuhe"
- "Bio-Öl"
- "Kosten", "Kostet", "Kaufen"
- "Verbesser", "Upgrade"

### English
- "upgrade", "buy", "improved", "better", "enhance"

### Custom Keywords
Du kannst weitere Keywords hinzufügen in `findUpgradeButtons()`

---

## 📹 Video Recognition

### Auto-Detect
- "Video"
- "Ad / Anzeige"
- "Bonus", "Claim", "Collect"
- "Skip", "Überspringen"
- "Loading"

### Skip-Button Variants
- Text: "Skip", "Überspringen"
- Symbol: "→" Pfeil
- Content: "next", "weiter", "dismiss"

---

## 🎯 Smart Detection

### UI Scanning
- Traverse komplettes Accessibility Tree
- Case-insensitive Text-Matching
- Clickable-State Prüfung
- Parent-Node Fallback

### De-Duplication
- Keine Duplikate von Buttons
- Distinct by HashCode
- Multi-Level Filtering

---

## 💾 Data & Persistence

### LocalStorage
- SharedPreferences für Config
- SharedPreferences für Stats
- No Cloud Sync (privat auf Handy)

### Exportable
- Logs via Timber/Logcat
- Stats in App sichtbar
- Config-Summary Anzeige

---

## 🔐 Privacy & Security

- ✅ Keine Internet-Requests (außer App-Updates)
- ✅ Keine externen Server-Kommunikation
- ✅ Alle Daten lokal auf Handy
- ✅ Keine Benutzerdaten-Sammlung
- ✅ Open-Source (Review möglich)

---

## 🚀 Geplante Features (TODO)

- [ ] Auto-Start beim Booten
- [ ] Multi-Account Support
- [ ] Web-Dashboard für Monitoring
- [ ] Notification bei Meilensteinen
- [ ] Video-Timeout Intelligenz (Variable Längen)
- [ ] Gesture-Based Clicking (statt Action APIs)
- [ ] Network Obfuscation
- [ ] Pattern Randomization
- [ ] Machine Learning für Button-Detection
- [ ] Cloud Sync (optional, privat)

---

## 🎨 UI Features

### Main Screen
- Status Indicator
- Start/Stop Controls
- Settings Button
- Accessibility Service Check

### Settings Screen
- Anti-Ban Toggle
- Random Delays Toggle
- Video/Upgrade Delay Sliders
- Button Filter Settings
- Statistics Display
- Save/Reset/Delete Buttons

### Real-time Feedback
- Emoji-basiertes Logging
- Status-Aktualisierungen
- Error Messages
- Stats Update

---

## 📈 Performance

### Optimized
- Effiziente Tree-Traversal
- Caching wo möglich
- Minimal CPU Usage
- Low Battery Impact
- Small APK (~5MB)

### Benchmarks
- Tree-Scan: ~100-200ms
- Button-Click: ~50ms
- Video-Wait: Optimized (mit Early Exit via Skip)
- UI Response: <100ms

---

## 🐛 Known Limitations

- Skip-Button kann manchmal nicht erkannt werden (kein Text-Label)
- Custom-Ads können längere Wartezeiten brauchen
- Sehr schnelles UI-Rendering kann zu Missed Clicks führen
- Manche Games haben Anti-Accessibility Technologien

---

## 📚 Tech Stack

- **Language**: Kotlin 1.9.0
- **Android**: API 21+ (5.0+)
- **Build**: Gradle 8.1
- **Logging**: Timber
- **Config**: SharedPreferences
- **UI**: Material Design
- **Accessibility**: Android Accessibility API

---

**Alle Features sind aktivierbar/deaktivierbar für volle Kontrolle!** 🎮
