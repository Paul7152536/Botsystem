# 🐙 GitHub Setup - Für Auto-Builds

## Warum GitHub?

✅ Automatische APK-Builds bei jedem Push (GitHub Actions)  
✅ Einfacher Versionen teilen (Releases)  
✅ Backup in der Cloud  
✅ Public oder Private Repository  

---

## 🚀 5-Schritt Setup

### Schritt 1: GitHub Account

Falls du noch keinen hast:
1. Gehe zu https://github.com/signup
2. Email + Password + Username
3. Email bestätigen
4. ✅ Fertig

---

### Schritt 2: Neues Repository erstellen

```
Auf GitHub:
1. Klick auf "+" (oben rechts)
2. "New repository"
3. Name: eatadventure-bot
4. Beschreibung: (optional) "Bot für eatadventure Game"
5. Public oder Private? (Private empfohlen!)
6. "Create repository"
```

---

### Schritt 3: Projekt hochladen

**Im Terminal (Mac/Linux):**

```bash
cd /pfad/zum/eatadventure-bot

# GitHub Remote hinzufügen
git remote add origin https://github.com/DEIN_USERNAME/eatadventure-bot.git

# Auf main branch umbenennen (falls noch nicht)
git branch -M main

# Hochladen!
git push -u origin main
```

**Auf Windows (Git Bash):**

```bash
# Gleich wie oben
cd C:\pfad\zum\eatadventure-bot
git remote add origin https://github.com/DEIN_USERNAME/eatadventure-bot.git
git branch -M main
git push -u origin main
```

**GitHub Desktop (Einfacher):**

1. GitHub Desktop öffnen
2. "Add" → "Add Existing Repository"
3. Ordner "eatadventure-bot" wählen
4. "Publish Repository" klicken
5. Name + Private einstellen
6. ✅ Fertig!

---

### Schritt 4: GitHub Actions aktivieren

```
Auf GitHub (dein Repository):
1. Settings → Actions
2. "General" Seite
3. "Allow all actions and reusable workflows" ✅
4. Save

GitHub Actions läuft jetzt automatisch!
```

---

### Schritt 5: APK bauen & runterladen

**Automatisch:**
```
Jedes Mal wenn du pushst:
GitHub → Actions → "Build APK"
→ Nach ~5 Minuten fertig
→ Klick auf Run
→ Scroll zu "Artifacts"
→ app-debug.apk runterladen
```

**Manuell im Terminal:**

```bash
cd eatadventure-bot

# Change something...
# Dann commit & push:

git add -A
git commit -m "feat: Some feature"
git push
```

**In GitHub anschauen:**

```
GitHub → Actions
→ Siehe dein Build laufen in real-time!
→ Grüner Haken = erfolgreich
→ Rotes X = Fehler
```

---

## 🎯 APK runterladen

### Von GitHub Actions Artifacts:

```
1. GitHub → Actions
2. Letzter erfolgreicher Run
3. Scroll to "Artifacts"
4. Klick "app-debug.apk"
5. Download!
```

### Von Releases (wenn du Tags machst):

```bash
# Tag erstellen:
git tag v2.0
git push origin v2.0

# GitHub macht automatisch einen "Release"
# Mit der APK!
```

---

## 📱 APK installieren

Nach dem Download:

### Mit ADB:
```bash
adb install app-debug.apk
```

### Manuell:
1. APK auf Handy kopieren (USB oder Cloud)
2. File Manager öffnen
3. APK antippen
4. "Unbekannte Quellen" erlauben
5. Install
6. ✅ Fertig

---

## 🔧 Feintuning

### Wenn du Updates machen willst:

```bash
# Code ändern...
git add -A
git commit -m "fix: Bug xy"
git push
# → GitHub baut automatisch neue APK!
```

### Neue Version releasen:

```bash
# Tag erstellen
git tag v2.1
git push origin v2.1

# Auf GitHub:
# Gehe zu Releases
# Editiere den Auto-Generated Release
# Upload die APK manuell (optional)
# Publish!
```

### Repository Settings

```
Auf GitHub → Settings:

General:
  - Repository name: eatadventure-bot ✅
  - Description: Bot für... ✅
  - Private: Ja/Nein

Actions:
  - Allow all actions ✅

Branches:
  - Default branch: main ✅
  - Branch protection (optional)
```

---

## 🆘 Troubleshooting

### Problem: "Permission denied"
```
→ Deine Credentials sind falsch
→ Nutze Personal Access Token statt Password
→ https://github.com/settings/tokens
```

### Problem: "Repository not found"
```
→ Wrong username/repository name
→ Check URL: https://github.com/USERNAME/eatadventure-bot
```

### Problem: GitHub Actions fail
```
→ Check the build log:
   GitHub → Actions → Failed Run
→ Scroll zu "Build APK" step
→ Siehe was kaputt ist
```

### Problem: APK zu groß
```
→ Normal, kein Problem
→ Größe: ~5-10MB
```

---

## 📊 Status überprüfen

```
GitHub Repository Stats:
- Commits: 5+ ✅
- Actions: Erfolgreiche Builds ✅
- APK: Always fresh ✅
- Code: Latest version ✅
```

---

## 🎉 Fertig!

Du hast jetzt:
- ✅ GitHub Repository
- ✅ Automatische APK-Builds
- ✅ Cloud Backup
- ✅ Version Control
- ✅ Einfacher Sharing

**Happy Coding!** 🚀

---

## 💡 Pro-Tipps

### Tip 1: .gitignore beachten
```
Folgende Dinge werden NICHT gepusht:
- /build/ (Kompilierte Files)
- .gradle/ (Gradle Cache)
- .idea/ (IDE Settings)
- *.apk (APK Files - bauen wir neuerdings!)

Das ist gut so! ✅
```

### Tip 2: Commit Messages
```
Gute Commits schreiben:
✅ "feat: Add new feature"
✅ "fix: Bug xy behoben"
✅ "docs: Update README"

Statt:
❌ "lol fixed it"
❌ "asdfghjkl"
❌ "kein Kommentar"
```

### Tip 3: Regelmäßig pushen
```
Mindestens 1x pro Woche pushen
→ Backup in der Cloud
→ History bleibt erhalten
→ Einfacher zu teilen
```

---

**Viel Erfolg!** 🎮✨
