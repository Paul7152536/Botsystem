package com.paulgorner.eatadventurebot

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.paulgorner.eatadventurebot.utils.RandomUtils
import com.paulgorner.eatadventurebot.utils.SettingsManager
import com.paulgorner.eatadventurebot.utils.StatsManager
import timber.log.Timber

class EatAdventureBotService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var isAutomationRunning = false
    private var isInVideoWait = false

    private lateinit var statsManager: StatsManager
    private lateinit var settingsManager: SettingsManager

    private val broadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ACTION_START_AUTOMATION -> startAutomation()
                ACTION_STOP_AUTOMATION -> stopAutomation()
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Timber.d("EatAdventure Bot Service connected")
        statsManager = StatsManager(this)
        settingsManager = SettingsManager(this)
        registerBroadcastReceiver()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!isAutomationRunning) return

        event?.let {
            Timber.d("Event: ${it.eventType} - ${it.text}")

            when {
                isVideoDetected(it) -> handleVideoWait()
                else -> processUpgrades()
            }
        }
    }

    override fun onInterrupt() {
        Timber.d("Service interrupted")
        stopAutomation()
    }

    private fun startAutomation() {
        if (isAutomationRunning) return
        isAutomationRunning = true
        statsManager.startSession()
        Timber.i("🚀 Automation started!")
        Timber.i(settingsManager.getConfigSummary())

        handler.postDelayed({
            processUpgrades()
        }, 1000)
    }

    private fun stopAutomation() {
        isAutomationRunning = false
        isInVideoWait = false
        statsManager.endSession()
        handler.removeCallbacksAndMessages(null)
        Timber.i("⏹️ Automation stopped!")
        Timber.i(statsManager.getStats())
    }

    /**
     * Main logic: Find and click upgrade buttons
     */
    private fun processUpgrades() {
        if (!isAutomationRunning) return

        val rootNode = rootInActiveWindow ?: return

        // ZUERST: Prüfe ob Skip-Button sichtbar ist (Video läuft noch)
        val skipButton = findSkipButton(rootNode)
        if (skipButton != null && isInVideoWait) {
            Timber.i("⏭️ Skip button found! Clicking...")
            clickNode(skipButton)
            statsManager.recordVideoWatched()

            // Nach Skip kurz warten bevor weiter
            isInVideoWait = false
            handler.postDelayed({
                processUpgrades()
            }, RandomUtils.getSkipDelay())
            return
        }

        // Suche nach Upgrade-Buttons
        val upgradeButtons = findUpgradeButtons(rootNode)

        if (upgradeButtons.isNotEmpty()) {
            Timber.d("Found ${upgradeButtons.size} upgrade buttons")

            // Klicke auf den ersten verfügbaren Button
            val button = upgradeButtons.first()
            clickNode(button)
            statsManager.recordUpgrade()

            // Nächste Aktion nach Verzögerung (mit Anti-Ban)
            val delay = if (settingsManager.isRandomDelaysEnabled()) {
                RandomUtils.getRandomUpgradeDelay()
            } else {
                settingsManager.getUpgradeDelay()
            }

            handler.postDelayed({
                processUpgrades()
            }, delay)
        } else {
            // Keine Upgrade-Buttons gefunden - schaue nach Video-Buttons
            val videoButtons = findVideoButtons(rootNode)

            if (videoButtons.isNotEmpty()) {
                Timber.d("Found ${videoButtons.size} video buttons")
                val videoButton = videoButtons.first()
                clickNode(videoButton)

                // Video-Wartezeit (mit Anti-Ban Randomisierung)
                isInVideoWait = true
                val videoWaitTime = if (settingsManager.isRandomDelaysEnabled()) {
                    RandomUtils.getRandomVideoDelay()
                } else {
                    settingsManager.getVideoWaitMax()
                }
                Timber.i("🎬 Video started, waiting max ${videoWaitTime}ms")

                handler.postDelayed({
                    if (isInVideoWait) {
                        isInVideoWait = false
                        Timber.i("⏱️ Video wait timeout - continuing")
                        processUpgrades()
                    }
                }, videoWaitTime)
            } else {
                // Nächsten Scan nach kurzer Zeit
                val scanDelay = if (settingsManager.isRandomDelaysEnabled()) {
                    RandomUtils.getRandomScanDelay()
                } else {
                    2000L
                }

                handler.postDelayed({
                    processUpgrades()
                }, scanDelay)
            }
        }
    }

    /**
     * Finde Skip-Button (Pfeil/Skip während Video läuft)
     */
    private fun findSkipButton(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val skipTriggers = listOf(
            "skip",
            "überspringen",
            "→",
            "pfeil",
            "next",
            "weiter",
            "dismiss",
            "close"
        )

        var foundSkip: AccessibilityNodeInfo? = null

        traverseNodes(root) { node ->
            val text = (node.text ?: "").toString().lowercase()
            val contentDesc = (node.contentDescription ?: "").toString().lowercase()

            if (skipTriggers.any { trigger ->
                text.contains(trigger.lowercase()) ||
                contentDesc.contains(trigger.lowercase())
            }) {
                if (node.isClickable || node.parent?.isClickable == true) {
                    Timber.d("🔍 Found potential skip button: $text")
                    foundSkip = node
                }
            }
        }

        return foundSkip
    }

    /**
     * Finde Upgrade-Buttons (mit Button-Filter)
     */
    private fun findUpgradeButtons(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val buttons = mutableListOf<AccessibilityNodeInfo>()

        val upgradeTriggers = listOf(
            "upgrade",
            "verbesser",
            "kosten",
            "kostet",
            "kaufen",
            "buy",
            "improved",
            "better",
            "enhance",
            "Echtes Hühnchen",
            "Verbesserte Hygiene",
            "Inline-Skates",
            "Bessere Handschuhe",
            "Bio-Öl"
        )

        val whitelist = settingsManager.getButtonWhitelist()
        val blacklist = settingsManager.getButtonBlacklist()
        val filterEnabled = settingsManager.isButtonFilterEnabled()

        traverseNodes(root) { node ->
            val text = (node.text ?: "").toString().lowercase()
            val contentDesc = (node.contentDescription ?: "").toString().lowercase()

            // Prüfe auf Upgrade-Keywords
            if (upgradeTriggers.any { trigger ->
                text.contains(trigger.lowercase()) ||
                contentDesc.contains(trigger.lowercase())
            }) {
                // Button-Filter anwenden wenn aktiviert
                if (filterEnabled) {
                    val isInWhitelist = whitelist.isEmpty() || whitelist.any { text.contains(it.lowercase()) }
                    val isInBlacklist = blacklist.any { text.contains(it.lowercase()) }

                    if (isInWhitelist && !isInBlacklist) {
                        if (node.isClickable || node.parent?.isClickable == true) {
                            buttons.add(node)
                            Timber.d("✅ Found upgrade button (filtered): $text")
                        }
                    }
                } else {
                    // Kein Filter - klicke alle
                    if (node.isClickable || node.parent?.isClickable == true) {
                        buttons.add(node)
                        Timber.d("Found upgrade button: $text")
                    }
                }
            }
        }

        return buttons.distinctBy { it.hashCode() }
    }

    /**
     * Finde Video-Buttons
     */
    private fun findVideoButtons(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val buttons = mutableListOf<AccessibilityNodeInfo>()

        val videoTriggers = listOf(
            "video",
            "video anschau",
            "watch",
            "ad",
            "anzeige",
            "bonus",
            "claim",
            "collect"
        )

        traverseNodes(root) { node ->
            val text = (node.text ?: "").toString().lowercase()
            val contentDesc = (node.contentDescription ?: "").toString().lowercase()

            if (videoTriggers.any { trigger ->
                text.contains(trigger.lowercase()) ||
                contentDesc.contains(trigger.lowercase())
            }) {
                if (node.isClickable || node.parent?.isClickable == true) {
                    buttons.add(node)
                    Timber.d("Found video button: $text")
                }
            }
        }

        return buttons.distinctBy { it.hashCode() }
    }

    /**
     * Erkenne Videos
     */
    private fun isVideoDetected(event: AccessibilityEvent): Boolean {
        val text = event.text.joinToString(" ").lowercase()
        return text.contains("video") ||
               text.contains("ad") ||
               text.contains("anzeige") ||
               text.contains("skip") ||
               text.contains("loading")
    }

    private fun handleVideoWait() {
        Timber.i("Video detected, waiting...")
        isInVideoWait = true
    }

    /**
     * Traverse Accessibility Tree
     */
    private fun traverseNodes(node: AccessibilityNodeInfo, callback: (AccessibilityNodeInfo) -> Unit) {
        callback(node)

        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            if (child != null) {
                traverseNodes(child, callback)
                child.recycle()
            }
        }
    }

    /**
     * Click on a node
     */
    private fun clickNode(node: AccessibilityNodeInfo) {
        // Versuche den Node selbst zu klicken
        if (!node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            // Fallback: Versuche Parent zu klicken
            node.parent?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            Timber.d("Clicked parent node")
        } else {
            Timber.d("Clicked node: ${node.text}")
        }
    }

    private fun registerBroadcastReceiver() {
        val filter = IntentFilter().apply {
            addAction(ACTION_START_AUTOMATION)
            addAction(ACTION_STOP_AUTOMATION)
        }
        registerReceiver(broadcastReceiver, filter, Context.RECEIVER_EXPORTED)
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(broadcastReceiver)
        stopAutomation()
    }

    companion object {
        const val ACTION_START_AUTOMATION = "com.paulgorner.eatadventurebot.START"
        const val ACTION_STOP_AUTOMATION = "com.paulgorner.eatadventurebot.STOP"
    }
}
