package com.paulgorner.eatadventurebot.utils

import kotlin.random.Random

/**
 * Utility für Anti-Ban Features
 * Randomisierte Delays um menschlicher zu wirken
 */
object RandomUtils {

    /**
     * Randomisierte Verzögerung für Upgrade-Clicks
     * Min: 500ms, Max: 2000ms (menschliches Timing)
     */
    fun getRandomUpgradeDelay(): Long {
        return Random.nextLong(500L, 2000L)
    }

    /**
     * Randomisierte Verzögerung für UI-Scans
     * Min: 1000ms, Max: 3000ms
     */
    fun getRandomScanDelay(): Long {
        return Random.nextLong(1000L, 3000L)
    }

    /**
     * Randomisierte Video-Wartezeit
     * Basis 120s + Random Offset
     */
    fun getRandomVideoDelay(): Long {
        val base = 120000L
        val offset = Random.nextLong(0L, 30000L) // +0 bis +30 Sekunden
        return base + offset
    }

    /**
     * Skip-Delay (schnell, aber nicht zu schnell)
     */
    fun getSkipDelay(): Long {
        return Random.nextLong(300L, 800L)
    }
}
