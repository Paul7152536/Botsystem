package com.paulgorner.eatadventurebot.utils

import android.content.Context
import android.content.SharedPreferences
import timber.log.Timber

/**
 * Verwaltet Konfigurationseinstellungen
 */
class SettingsManager(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("eatadventure_settings", Context.MODE_PRIVATE)

    companion object {
        // Keys
        private const val KEY_ANTI_BAN_ENABLED = "anti_ban_enabled"
        private const val KEY_RANDOM_DELAYS = "random_delays"
        private const val KEY_VIDEO_WAIT_MAX = "video_wait_max"
        private const val KEY_UPGRADE_DELAY = "upgrade_delay"
        private const val KEY_BUTTON_FILTER_ENABLED = "button_filter_enabled"
        private const val KEY_BUTTON_WHITELIST = "button_whitelist"
        private const val KEY_BUTTON_BLACKLIST = "button_blacklist"
        private const val KEY_AUTO_START = "auto_start"

        // Default Values
        const val DEFAULT_VIDEO_WAIT_MAX = 120000L // 120 Sekunden
        const val DEFAULT_UPGRADE_DELAY = 800L // 800ms
    }

    // Anti-Ban Settings
    fun isAntiBanEnabled(): Boolean = prefs.getBoolean(KEY_ANTI_BAN_ENABLED, true)
    fun setAntiBanEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_ANTI_BAN_ENABLED, enabled).apply()
        Timber.i("🛡️ Anti-Ban: $enabled")
    }

    fun isRandomDelaysEnabled(): Boolean = prefs.getBoolean(KEY_RANDOM_DELAYS, true)
    fun setRandomDelaysEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_RANDOM_DELAYS, enabled).apply()
        Timber.i("🎲 Random Delays: $enabled")
    }

    // Video Settings
    fun getVideoWaitMax(): Long = prefs.getLong(KEY_VIDEO_WAIT_MAX, DEFAULT_VIDEO_WAIT_MAX)
    fun setVideoWaitMax(millis: Long) {
        prefs.edit().putLong(KEY_VIDEO_WAIT_MAX, millis).apply()
        Timber.i("🎬 Video Max Wait: ${millis}ms")
    }

    fun getUpgradeDelay(): Long = prefs.getLong(KEY_UPGRADE_DELAY, DEFAULT_UPGRADE_DELAY)
    fun setUpgradeDelay(millis: Long) {
        prefs.edit().putLong(KEY_UPGRADE_DELAY, millis).apply()
        Timber.i("⏱️ Upgrade Delay: ${millis}ms")
    }

    // Button Filter Settings
    fun isButtonFilterEnabled(): Boolean = prefs.getBoolean(KEY_BUTTON_FILTER_ENABLED, false)
    fun setButtonFilterEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_BUTTON_FILTER_ENABLED, enabled).apply()
        Timber.i("🔍 Button Filter: $enabled")
    }

    fun getButtonWhitelist(): Set<String> = prefs.getStringSet(KEY_BUTTON_WHITELIST, emptySet()) ?: emptySet()
    fun setButtonWhitelist(buttons: Set<String>) {
        prefs.edit().putStringSet(KEY_BUTTON_WHITELIST, buttons).apply()
        Timber.i("✅ Whitelist set: $buttons")
    }

    fun getButtonBlacklist(): Set<String> = prefs.getStringSet(KEY_BUTTON_BLACKLIST, emptySet()) ?: emptySet()
    fun setButtonBlacklist(buttons: Set<String>) {
        prefs.edit().putStringSet(KEY_BUTTON_BLACKLIST, buttons).apply()
        Timber.i("❌ Blacklist set: $buttons")
    }

    // Auto-Start
    fun isAutoStartEnabled(): Boolean = prefs.getBoolean(KEY_AUTO_START, false)
    fun setAutoStartEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AUTO_START, enabled).apply()
        Timber.i("🚀 Auto-Start: $enabled")
    }

    /**
     * Config Summary
     */
    fun getConfigSummary(): String {
        return """
            ⚙️ Bot Configuration
            ──────────────────
            🛡️ Anti-Ban: ${if (isAntiBanEnabled()) "ON" else "OFF"}
            🎲 Random Delays: ${if (isRandomDelaysEnabled()) "ON" else "OFF"}
            🎬 Video Max: ${getVideoWaitMax()}ms
            ⏱️ Upgrade Delay: ${getUpgradeDelay()}ms
            🔍 Button Filter: ${if (isButtonFilterEnabled()) "ON" else "OFF"}
            🚀 Auto-Start: ${if (isAutoStartEnabled()) "ON" else "OFF"}
        """.trimIndent()
    }

    /**
     * Reset to Defaults
     */
    fun resetToDefaults() {
        prefs.edit().clear().apply()
        Timber.i("⚙️ Settings reset to defaults")
    }
}
