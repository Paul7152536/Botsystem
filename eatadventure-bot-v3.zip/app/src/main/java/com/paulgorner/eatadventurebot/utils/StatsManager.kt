package com.paulgorner.eatadventurebot.utils

import android.content.Context
import android.content.SharedPreferences
import timber.log.Timber

/**
 * Verwaltet Statistiken über Bot-Aktivitäten
 * Speichert: Upgrades, Videos, Sessions, Zeit
 */
class StatsManager(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("eatadventure_stats", Context.MODE_PRIVATE)

    // Keys
    companion object {
        private const val KEY_UPGRADES_TOTAL = "upgrades_total"
        private const val KEY_VIDEOS_WATCHED = "videos_watched"
        private const val KEY_SESSIONS_COUNT = "sessions_count"
        private const val KEY_RUNTIME_MINUTES = "runtime_minutes"
        private const val KEY_LAST_SESSION_TIME = "last_session_time"
        private const val KEY_SESSION_START = "session_start_time"
    }

    /**
     * Increment Upgrade Counter
     */
    fun recordUpgrade() {
        val current = getTotalUpgrades()
        prefs.edit().putInt(KEY_UPGRADES_TOTAL, current + 1).apply()
        Timber.i("📊 Stats: Upgrades = ${current + 1}")
    }

    /**
     * Increment Video Counter
     */
    fun recordVideoWatched() {
        val current = getVideosWatched()
        prefs.edit().putInt(KEY_VIDEOS_WATCHED, current + 1).apply()
        Timber.i("📊 Stats: Videos = ${current + 1}")
    }

    /**
     * Start neue Session
     */
    fun startSession() {
        val startTime = System.currentTimeMillis()
        prefs.edit().putLong(KEY_SESSION_START, startTime).apply()
        Timber.i("📊 Session started at ${System.currentTimeMillis()}")
    }

    /**
     * End Session und speichere Stats
     */
    fun endSession() {
        val startTime = prefs.getLong(KEY_SESSION_START, 0L)
        if (startTime > 0) {
            val duration = System.currentTimeMillis() - startTime
            val minutes = duration / 60000

            val current = getRuntime()
            prefs.edit().apply {
                putInt(KEY_RUNTIME_MINUTES, current + minutes.toInt())
                putInt(KEY_SESSIONS_COUNT, getSessionsCount() + 1)
                putLong(KEY_LAST_SESSION_TIME, System.currentTimeMillis())
                putLong(KEY_SESSION_START, 0L)
                apply()
            }

            Timber.i("📊 Session ended. Duration: ${minutes}min, Total: ${current + minutes}min")
        }
    }

    // Getters
    fun getTotalUpgrades(): Int = prefs.getInt(KEY_UPGRADES_TOTAL, 0)
    fun getVideosWatched(): Int = prefs.getInt(KEY_VIDEOS_WATCHED, 0)
    fun getSessionsCount(): Int = prefs.getInt(KEY_SESSIONS_COUNT, 0)
    fun getRuntime(): Int = prefs.getInt(KEY_RUNTIME_MINUTES, 0)
    fun getLastSessionTime(): Long = prefs.getLong(KEY_LAST_SESSION_TIME, 0L)

    /**
     * Statistik-Summary
     */
    fun getStats(): String {
        return """
            📊 Bot Statistics
            ─────────────────
            ✅ Upgrades: ${getTotalUpgrades()}
            🎬 Videos: ${getVideosWatched()}
            ⏱️ Runtime: ${getRuntime()}min
            🔄 Sessions: ${getSessionsCount()}
        """.trimIndent()
    }

    /**
     * Reset all Stats
     */
    fun resetStats() {
        prefs.edit().clear().apply()
        Timber.i("📊 Stats reset")
    }
}
