package com.paulgorner.eatadventurebot

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import timber.log.Timber

class MainActivity : AppCompatActivity() {

    private lateinit var statusTextView: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var enableButton: Button
    private lateinit var settingsButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Timber.plant(Timber.DebugTree())

        initViews()
        updateStatus()
    }

    private fun initViews() {
        statusTextView = findViewById(R.id.statusTextView)
        startButton = findViewById(R.id.startButton)
        stopButton = findViewById(R.id.stopButton)
        enableButton = findViewById(R.id.enableButton)
        settingsButton = findViewById(R.id.settingsButton)

        startButton.setOnClickListener {
            startAutomation()
        }

        stopButton.setOnClickListener {
            stopAutomation()
        }

        enableButton.setOnClickListener {
            openAccessibilitySettings()
        }

        settingsButton.setOnClickListener {
            openSettings()
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val isServiceEnabled = isAccessibilityServiceEnabled()

        statusTextView.text = if (isServiceEnabled) {
            "✅ Service aktiviert\nKlick 'Start' um Automation zu beginnen"
        } else {
            "❌ Service nicht aktiviert\nBitte erst Service aktivieren"
        }

        startButton.isEnabled = isServiceEnabled
        enableButton.visibility = if (isServiceEnabled) Button.GONE else Button.VISIBLE
    }

    private fun startAutomation() {
        if (!isAccessibilityServiceEnabled()) {
            statusTextView.text = "❌ Accessibility Service erst aktivieren!"
            return
        }

        val intent = Intent(EatAdventureBotService.ACTION_START_AUTOMATION)
        intent.setPackage(packageName)
        sendBroadcast(intent)

        statusTextView.text = "🤖 Automation läuft...\n(Bot klickt automatisch Upgrades)"
        startButton.isEnabled = false
        stopButton.isEnabled = true

        Timber.i("Automation broadcast sent")
    }

    private fun stopAutomation() {
        val intent = Intent(EatAdventureBotService.ACTION_STOP_AUTOMATION)
        intent.setPackage(packageName)
        sendBroadcast(intent)

        statusTextView.text = "⏸️ Automation gestoppt"
        startButton.isEnabled = true
        stopButton.isEnabled = false

        Timber.i("Stop broadcast sent")
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val accessibilityManager = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = accessibilityManager.getEnabledAccessibilityServiceList(
            AccessibilityServiceInfo.FEEDBACK_ALL_MASK
        )

        return enabledServices.any { service ->
            service.id.contains("eatadventurebot")
        }
    }

    private fun openAccessibilitySettings() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }
}
