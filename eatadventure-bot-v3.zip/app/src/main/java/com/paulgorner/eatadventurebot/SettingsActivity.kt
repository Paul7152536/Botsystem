package com.paulgorner.eatadventurebot

import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.paulgorner.eatadventurebot.utils.SettingsManager
import com.paulgorner.eatadventurebot.utils.StatsManager
import timber.log.Timber

class SettingsActivity : AppCompatActivity() {

    private lateinit var settingsManager: SettingsManager
    private lateinit var statsManager: StatsManager

    // UI Elements
    private lateinit var antiBanCheckBox: CheckBox
    private lateinit var randomDelaysCheckBox: CheckBox
    private lateinit var videoWaitSeekBar: SeekBar
    private lateinit var upgradeDelaySeekBar: SeekBar
    private lateinit var buttonFilterCheckBox: CheckBox
    private lateinit var autoStartCheckBox: CheckBox

    private lateinit var statsTextView: TextView
    private lateinit var videoWaitLabel: TextView
    private lateinit var upgradeDelayLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        settingsManager = SettingsManager(this)
        statsManager = StatsManager(this)

        initViews()
        loadSettings()
        setupListeners()
    }

    private fun initViews() {
        // Checkboxes
        antiBanCheckBox = findViewById(R.id.antiBanCheckBox)
        randomDelaysCheckBox = findViewById(R.id.randomDelaysCheckBox)
        buttonFilterCheckBox = findViewById(R.id.buttonFilterCheckBox)
        autoStartCheckBox = findViewById(R.id.autoStartCheckBox)

        // SeekBars
        videoWaitSeekBar = findViewById(R.id.videoWaitSeekBar)
        upgradeDelaySeekBar = findViewById(R.id.upgradeDelaySeekBar)

        // Labels
        videoWaitLabel = findViewById(R.id.videoWaitLabel)
        upgradeDelayLabel = findViewById(R.id.upgradeDelayLabel)

        // Stats
        statsTextView = findViewById(R.id.statsTextView)

        // Buttons
        val saveButton: Button = findViewById(R.id.saveButton)
        val resetButton: Button = findViewById(R.id.resetButton)
        val statsResetButton: Button = findViewById(R.id.statsResetButton)

        saveButton.setOnClickListener { saveSettings() }
        resetButton.setOnClickListener { resetSettings() }
        statsResetButton.setOnClickListener { resetStats() }
    }

    private fun loadSettings() {
        antiBanCheckBox.isChecked = settingsManager.isAntiBanEnabled()
        randomDelaysCheckBox.isChecked = settingsManager.isRandomDelaysEnabled()
        buttonFilterCheckBox.isChecked = settingsManager.isButtonFilterEnabled()
        autoStartCheckBox.isChecked = settingsManager.isAutoStartEnabled()

        // SeekBars (0-200, representing 0-120000ms)
        val videoWaitValue = settingsManager.getVideoWaitMax() / 600 // 120s = 200
        val upgradeDelayValue = settingsManager.getUpgradeDelay() / 10 // 800ms = 80

        videoWaitSeekBar.progress = videoWaitValue.toInt()
        upgradeDelaySeekBar.progress = upgradeDelayValue.toInt()

        updateLabels()
        updateStats()
    }

    private fun setupListeners() {
        videoWaitSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                updateLabels()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        upgradeDelaySeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                updateLabels()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        randomDelaysCheckBox.setOnCheckedChangeListener { _, isChecked ->
            // Disable manual delays if random is enabled
            upgradeDelaySeekBar.isEnabled = !isChecked
            videoWaitSeekBar.isEnabled = !isChecked
        }
    }

    private fun updateLabels() {
        val videoWaitMs = videoWaitSeekBar.progress * 600
        val upgradeDelayMs = upgradeDelaySeekBar.progress * 10

        videoWaitLabel.text = "Video Wait: ${videoWaitMs}ms (${videoWaitMs / 1000}s)"
        upgradeDelayLabel.text = "Upgrade Delay: ${upgradeDelayMs}ms"
    }

    private fun updateStats() {
        statsTextView.text = statsManager.getStats()
    }

    private fun saveSettings() {
        settingsManager.setAntiBanEnabled(antiBanCheckBox.isChecked)
        settingsManager.setRandomDelaysEnabled(randomDelaysCheckBox.isChecked)
        settingsManager.setButtonFilterEnabled(buttonFilterCheckBox.isChecked)
        settingsManager.setAutoStartEnabled(autoStartCheckBox.isChecked)

        val videoWaitMs = (videoWaitSeekBar.progress * 600).toLong()
        val upgradeDelayMs = (upgradeDelaySeekBar.progress * 10).toLong()

        settingsManager.setVideoWaitMax(videoWaitMs)
        settingsManager.setUpgradeDelay(upgradeDelayMs)

        Timber.i("⚙️ Settings saved!")
        showToast("✅ Einstellungen gespeichert!")
    }

    private fun resetSettings() {
        settingsManager.resetToDefaults()
        loadSettings()
        Timber.i("⚙️ Settings reset!")
        showToast("⚙️ Einstellungen zurückgesetzt")
    }

    private fun resetStats() {
        statsManager.resetStats()
        updateStats()
        Timber.i("📊 Stats reset!")
        showToast("📊 Statistik zurückgesetzt")
    }

    private fun showToast(message: String) {
        android.widget.Toast.makeText(this, message, android.widget.Toast.LENGTH_SHORT).show()
    }
}
