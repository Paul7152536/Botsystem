# Timber
-keep class timber.log.Timber* { *; }

# Keep accessibility service
-keep class com.paulgorner.eatadventurebot.EatAdventureBotService { *; }
-keep class com.paulgorner.eatadventurebot.MainActivity { *; }

# Keep all public methods
-keepclassmembers class * {
    public <methods>;
}
