# 📱 Installationsanleitung - eatadventure Bot

## Schritt-für-Schritt Installation

### 1️⃣ APK herunterladen

Gehe zu **[Releases](https://github.com/paulgorner/eatadventure-bot/releases)** und lade die neueste Version herunter:

```
app-debug.apk (z.B. eatadventure-bot-1.0.0.apk)
```

### 2️⃣ Android vorbereiten

#### Option A: USB-Debugging (mit Computer)

1. Handy mit USB-Kabel verbinden
2. Einstellungen → Entwickler-Optionen aktivieren (7x auf Build-Nummer tippen)
3. USB-Debugging aktivieren
4. Im Terminal ausführen:

```bash
adb install app-debug.apk
```

#### Option B: Direkter Download (ohne Computer)

1. **Einstellungen** → **Apps & Benachrichtigungen**
2. **Unbekannte Quellen** erlauben (oder ähnlich)
3. **Dateimanager** öffnen
4. `app-debug.apk` aussuchen und tippen
5. Installation bestätigen

### 3️⃣ Accessibility Service freischalten

**Das ist WICHTIG - ohne dieser Erlaubnis funktioniert der Bot nicht!**

1. **eatadventure Bot App** öffnen
2. Button **"🔧 Accessibility Service aktivieren"** klicken
3. Du wirst zu **Einstellungen** weitergeleitet
4. Pfad: `Einstellungen → Bedienungshilfen → Dienste`
5. Suche nach **"eatadventure Bot"** oder **"EatAdventureBotService"**
6. Schieber auf **AN** stellen
7. Popup-Warnung mit **"Erlauben"** bestätigen

### 4️⃣ Bot starten

1. **eatadventure** öffnen (im Hintergrund)
2. **eatadventure Bot** App öffnen
3. Status sollte jetzt sein: `✅ Service aktiviert`
4. Button **"▶️ Automation starten"** klicken
5. Der Bot läuft jetzt! 🤖

---

## ✅ Checkliste vor dem Start

- [ ] APK installiert
- [ ] Accessibility Service aktiviert (Status zeigt ✅)
- [ ] eatadventure im Hintergrund geöffnet
- [ ] Handy nicht in Ruhestand
- [ ] Bildschirmsperre deaktiviert oder Smartlock aktiviert

---

## 🎮 Bot in Aktion

Der Bot wird automatisch:

✅ Nach Upgrade-Buttons suchen  
✅ Sie klicken wenn verfügbar  
✅ Video-Anzeigen anschauen (45 Sekunden warten)  
✅ Intelligente Verzögerungen einbauen  
✅ Loop wiederholen  

---

## 🛑 Bot stoppen

1. **eatadventure Bot** App öffnen
2. Button **"⏹️ Automation stoppen"** klicken
3. Status: `⏸️ Automation gestoppt`

---

## 🔧 Troubleshooting

### Problem: "❌ Service nicht aktiviert"

**Lösung:**
- Gehe zu `Einstellungen → Bedienungshilfen`
- Suche nach "eatadventure Bot"
- Aktiviere den Schieber

### Problem: Bot klickt nicht

**Checklist:**
- [ ] Ist der Service wirklich aktiviert? (Status ✅)
- [ ] Läuft eatadventure im Hintergrund?
- [ ] Handy ist nicht entsperrt? (Bildschirm an)
- [ ] Internet-Verbindung okay?

### Problem: App crasht

**Lösung:**
1. App deinstallieren
2. Handy neustart
3. App neu installieren
4. Service erneut aktivieren

### Problem: Zu viele Fehler erkannt

- Deinstallieren → Neustart → Neuinstallation

---

## 📊 Logs anschauen (Entwickler)

Falls du Debug-Logs sehen möchtest:

```bash
adb logcat | grep eatadventure
```

---

## ⚠️ Wichtige Erinnerungen

🔴 **NUR auf Test-Account testen!**  
🔴 **Das Spiel kann dich bannen wenn erkannt!**  
🔴 **Nicht 24/7 laufen lassen!**  
🔴 **Account-Aktivität kontrollieren!**  

---

## 🆘 Noch Probleme?

[Öffne ein Issue auf GitHub](https://github.com/paulgorner/eatadventure-bot/issues)

Beschreibe:
- Android-Version
- Handy-Modell
- Was genau passiert
- Logcat Output (wenn möglich)

---

**Viel Spaß! 🚀**
