package com.eatadventure.bot

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.TextView
import android.widget.EditText
import android.widget.Switch
import androidx.preference.PreferenceManager

class MainActivity : AppCompatActivity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var tvStatus: TextView
    private lateinit var etDelay: EditText
    private lateinit var swRecording: Switch
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = PreferenceManager.getDefaultSharedPreferences(this)

        tvStatus = findViewById(R.id.tv_status)
        etDelay = findViewById(R.id.et_delay)
        swRecording = findViewById(R.id.sw_recording)
        btnStart = findViewById(R.id.btn_start)
        btnStop = findViewById(R.id.btn_stop)
        val btnSettings = findViewById<Button>(R.id.btn_settings)

        // Load saved delay
        val savedDelay = prefs.getInt("bot_delay", 500)
        etDelay.setText(savedDelay.toString())

        // Recording mode toggle
        swRecording.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("recording_mode", isChecked).apply()
            updateStatus()
        }

        // Start bot
        btnStart.setOnClickListener {
            val delay = etDelay.text.toString().toIntOrNull() ?: 500
            prefs.edit()
                .putInt("bot_delay", delay)
                .putBoolean("bot_enabled", true)
                .apply()
            updateStatus()
        }

        // Stop bot
        btnStop.setOnClickListener {
            prefs.edit().putBoolean("bot_enabled", false).apply()
            updateStatus()
        }

        // Open accessibility settings
        btnSettings.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        updateStatus()
    }

    private fun updateStatus() {
        val botEnabled = prefs.getBoolean("bot_enabled", false)
        val recordingMode = prefs.getBoolean("recording_mode", false)
        val delay = prefs.getInt("bot_delay", 500)
        val recordedClicks = prefs.getInt("recorded_clicks", 0)

        val status = buildString {
            appendLine("=== EatAdventure Bot Status ===")
            appendLine("Bot: ${if (botEnabled) "🟢 LÄUFT" else "🔴 GESTOPPT"}")
            appendLine("Recording: ${if (recordingMode) "🔴 AKTIV" else "⚪ AUS"}")
            appendLine("Verzögerung: ${delay}ms")
            appendLine("Aufgezeichnete Klicks: $recordedClicks")
            appendLine("")
            appendLine("Accessibility Service: Bitte aktivieren")
            appendLine("in Einstellungen → Barrierefreiheit")
        }

        tvStatus.text = status
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }
}
