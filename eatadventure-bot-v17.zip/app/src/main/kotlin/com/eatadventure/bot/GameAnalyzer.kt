package com.eatadventure.bot

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs

/**
 * Analysiert Screenshots um Spielzustand zu verstehen
 */
class GameAnalyzer {

    data class GameObject(
        val type: ObjectType,
        val x: Int,
        val y: Int,
        val confidence: Float
    )

    enum class ObjectType {
        COOKED_DISH,      // Fertige Gerichte (rote/braune Farbe)
        GUEST,            // Gäste (gelbe Bereiche)
        COOKING_POT,      // Kochplätze
        FOOD_POPUP,       // Essenslieferung Popup
        ACCEPT_BUTTON,    // Akzeptieren Button
        REJECT_BUTTON     // Ablehnen Button
    }

    fun analyzeScreenshot(bitmap: Bitmap): List<GameObject> {
        val objects = mutableListOf<GameObject>()
        val pixels = IntArray(bitmap.width * bitmap.height)
        bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)

        // Finde fertige Gerichte (rote/braune Farben)
        val cookedDishes = detectColor(pixels, bitmap.width, bitmap.height,
            targetColor = Color.rgb(200, 80, 80), tolerance = 40)
        cookedDishes.forEach { (x, y) ->
            objects.add(GameObject(ObjectType.COOKED_DISH, x, y, 0.8f))
        }

        // Finde Gäste (gelbe Bereiche)
        val guests = detectColor(pixels, bitmap.width, bitmap.height,
            targetColor = Color.rgb(220, 200, 80), tolerance = 50)
        guests.forEach { (x, y) ->
            objects.add(GameObject(ObjectType.GUEST, x, y, 0.7f))
        }

        // Finde Kochplätze (dunkelbraun/schwarz)
        val pots = detectColor(pixels, bitmap.width, bitmap.height,
            targetColor = Color.rgb(100, 60, 40), tolerance = 30)
        pots.forEach { (x, y) ->
            objects.add(GameObject(ObjectType.COOKING_POT, x, y, 0.6f))
        }

        // Erkenne Buttons (blau = Akzeptieren, rot = Ablehnen)
        val acceptButtons = detectColor(pixels, bitmap.width, bitmap.height,
            targetColor = Color.rgb(100, 180, 220), tolerance = 40)
        acceptButtons.forEach { (x, y) ->
            objects.add(GameObject(ObjectType.ACCEPT_BUTTON, x, y, 0.9f))
        }

        val rejectButtons = detectColor(pixels, bitmap.width, bitmap.height,
            targetColor = Color.rgb(220, 80, 80), tolerance = 40)
        rejectButtons.forEach { (x, y) ->
            objects.add(GameObject(ObjectType.REJECT_BUTTON, x, y, 0.9f))
        }

        return objects
    }

    private fun detectColor(
        pixels: IntArray,
        width: Int,
        height: Int,
        targetColor: Int,
        tolerance: Int
    ): List<Pair<Int, Int>> {
        val positions = mutableListOf<Pair<Int, Int>>()
        val targetR = Color.red(targetColor)
        val targetG = Color.green(targetColor)
        val targetB = Color.blue(targetColor)

        for (i in pixels.indices) {
            val pixel = pixels[i]
            val r = Color.red(pixel)
            val g = Color.green(pixel)
            val b = Color.blue(pixel)

            if (abs(r - targetR) < tolerance &&
                abs(g - targetG) < tolerance &&
                abs(b - targetB) < tolerance) {
                val x = i % width
                val y = i / width
                positions.add(Pair(x, y))
            }
        }

        // Cluster nearby pixels
        return clusterPositions(positions)
    }

    private fun clusterPositions(positions: List<Pair<Int, Int>>): List<Pair<Int, Int>> {
        if (positions.isEmpty()) return emptyList()

        val clusters = mutableListOf<Pair<Int, Int>>()
        val used = mutableSetOf<Int>()

        for (i in positions.indices) {
            if (i in used) continue

            var sumX = 0
            var sumY = 0
            var count = 0

            for (j in positions.indices) {
                if (j in used) continue
                val dist = Math.hypot(
                    (positions[i].first - positions[j].first).toDouble(),
                    (positions[i].second - positions[j].second).toDouble()
                )
                if (dist < 50) {
                    sumX += positions[j].first
                    sumY += positions[j].second
                    count++
                    used.add(j)
                }
            }

            if (count > 0) {
                clusters.add(Pair(sumX / count, sumY / count))
            }
        }

        return clusters
    }

    fun findBestStrategy(objects: List<GameObject>): List<ClickAction> {
        val actions = mutableListOf<ClickAction>()

        // Strategie: Beste Deals akzeptieren, dann Gerichte kochen und servieren
        val acceptButtons = objects.filter { it.type == ObjectType.ACCEPT_BUTTON }
        val cookedDishes = objects.filter { it.type == ObjectType.COOKED_DISH }
        val guests = objects.filter { it.type == ObjectType.GUEST }

        // Akzeptiere gute Deals
        acceptButtons.take(2).forEach { button ->
            actions.add(ClickAction(button.x, button.y, 300))
        }

        // Serviere Gerichte
        cookedDishes.forEach { dish ->
            guests.randomOrNull()?.let { guest ->
                actions.add(ClickAction(dish.x, dish.y, 200))
                actions.add(ClickAction(guest.x, guest.y, 200))
            }
        }

        // Koche neue Gerichte
        val pots = objects.filter { it.type == ObjectType.COOKING_POT }
        pots.forEach { pot ->
            actions.add(ClickAction(pot.x, pot.y, 500))
        }

        return actions
    }

    data class ClickAction(
        val x: Int,
        val y: Int,
        val delayMs: Int
    )
}
