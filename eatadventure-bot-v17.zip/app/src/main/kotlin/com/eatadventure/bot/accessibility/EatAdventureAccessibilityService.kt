package com.eatadventure.bot.accessibility

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.preference.PreferenceManager
import com.eatadventure.bot.GameAnalyzer

class EatAdventureAccessibilityService : AccessibilityService() {

    private val gameAnalyzer = GameAnalyzer()
    private val handler = Handler(Looper.getMainLooper())
    private var isRunning = false
    private var lastAnalysisTime = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        val prefs = PreferenceManager.getDefaultSharedPreferences(this)
        prefs.edit().putBoolean("service_connected", true).apply()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val prefs = PreferenceManager.getDefaultSharedPreferences(this)

        val botEnabled = prefs.getBoolean("bot_enabled", false)
        if (!botEnabled) return

        // Analysiere Screenshot und spiele intelligent
        analyzeAndPlay()
    }

    private fun analyzeAndPlay() {
        // Limiting analysis frequency um Handy nicht zu überlasten
        val now = System.currentTimeMillis()
        if (now - lastAnalysisTime < 500) return
        lastAnalysisTime = now

        Thread {
            try {
                val screenshot = captureScreenshot()
                if (screenshot != null) {
                    val objects = gameAnalyzer.analyzeScreenshot(screenshot)
                    val actions = gameAnalyzer.findBestStrategy(objects)

                    executeActions(actions)
                    screenshot.recycle()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
    }

    private fun captureScreenshot(): Bitmap? {
        return try {
            rootInActiveWindow?.let { root ->
                // Erstelle einen Bitmap aus dem Root Node
                val width = 1080
                val height = 2340
                Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun executeActions(actions: List<GameAnalyzer.ClickAction>) {
        var delayAccum = 0L

        actions.forEach { action ->
            handler.postDelayed({
                performClick(action.x, action.y)
            }, delayAccum)

            delayAccum += action.delayMs
        }
    }

    private fun performClick(x: Int, y: Int) {
        try {
            // Erstelle einen Path für den Klick
            val info = AccessibilityNodeInfo()

            // Finde den Node an dieser Position
            rootInActiveWindow?.let { root ->
                val foundNode = findNodeAt(root, x, y)
                if (foundNode?.isClickable == true) {
                    foundNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                } else {
                    // Fallback: Nutze Touch Simulation
                    sendTap(x, y)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun findNodeAt(
        node: AccessibilityNodeInfo,
        x: Int,
        y: Int
    ): AccessibilityNodeInfo? {
        val bounds = android.graphics.Rect()
        node.getBoundsInScreen(bounds)

        if (bounds.contains(x, y)) {
            // Check children first
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { child ->
                    val result = findNodeAt(child, x, y)
                    if (result != null) return result
                }
            }
            return node
        }

        return null
    }

    private fun sendTap(x: Int, y: Int) {
        try {
            val gestureDescription = android.accessibilityservice.GestureDescription.Builder()
                .addStroke(
                    android.accessibilityservice.GestureDescription.StrokeDescription(
                        android.graphics.Path().apply {
                            moveTo(x.toFloat(), y.toFloat())
                            lineTo((x + 1).toFloat(), (y + 1).toFloat())
                        },
                        0, 100
                    )
                )
                .build()

            dispatchGesture(gestureDescription, null, null)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onInterrupt() {
        isRunning = false
    }
}
