# EatAdventure Bot v4

Automatischer Bot für EatAdventure - Gebaut mit Gradle 8.7 und Android SDK 33.

## ✅ Was ist neu in v4?

- ✅ `gradle.properties` mit `android.useAndroidX=true`
- ✅ AccessibilityService aktualisiert auf v1.1.0
- ✅ Alle Dependencies auf aktuelle, stabile Versionen
- ✅ Java 17 Unterstützung
- ✅ Optimierter GitHub Actions Workflow

## 📱 Installation am Handy

1. Öffne GitHub → dein Repo
2. Klick "Add file" → "Create new file"
3. Lade alle Dateien aus dem Root dieser ZIP hoch
4. Gehe zu Actions → "Build APK" → "Run workflow"
5. Warte ~2-3 Minuten
6. Download APK aus Artifacts
7. Installiere auf deinem Handy

## 📋 Dateistruktur

```
eatadventure-bot/
├── gradle.properties          ← AndroidX Konfiguration
├── build.gradle.kts           ← Projekt Konfiguration
├── settings.gradle.kts        ← Gradle Settings
├── app/
│   ├── build.gradle.kts       ← App Konfiguration (AKTUALISIERT)
│   ├── src/main/
│   │   ├── kotlin/            ← Kotlin Quellcode
│   │   ├── res/               ← Ressourcen
│   │   └── AndroidManifest.xml
│   └── proguard/
├── gradle/wrapper/            ← Gradle Wrapper
├── .github/workflows/
│   └── build-apk.yml          ← GitHub Actions
└── README.md
```

## 🔧 Wichtige Dateien

### gradle.properties (ROOT)
```properties
android.useAndroidX=true
android.enableJetifier=true
org.gradle.jvmargs=-Xmx2048m
```

### app/build.gradle.kts (AKTUALISIERT)
- AccessibilityService 1.1.0 (nicht 1.0.1!)
- Alle Dependencies auf stabile Versionen
- Java 17 Compiler
- Android compileSdk 33

## 🚀 Build starten

1. GitHub → Actions Tab
2. "Build APK" Workflow
3. "Run workflow" Button
4. Warten...
5. APK downloaden!

## ⚠️ Troubleshooting

Wenn Build fehlschlägt:
1. Öffne Workflow Run
2. Schau in die Logs
3. Sag mir die Error-Message!

## 📄 Lizenz

Lizenziert unter MIT

