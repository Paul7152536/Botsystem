# EatAdventure Bot Proguard Rules

# Keep all app classes
-keep class com.eatadventure.bot.** { *; }

# Keep accessibility service
-keep class * extends android.accessibilityservice.AccessibilityService { *; }

# Keep ML Kit classes
-keep class com.google.mlkit.** { *; }

# Keep AndroidX
-keep class androidx.** { *; }

# Keep Android classes
-keepclasseswithmembernames class * {
    native <methods>;
}

-keepclasseswithmembers class * {
    public <init>(android.content.Context, android.util.AttributeSet);
}

-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver

-dontwarn android.**
-dontwarn androidx.**
-dontwarn com.google.**
