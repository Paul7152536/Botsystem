# Dateistruktur

Folgende Dateien müssen in deinem Repository sein:

```
eatadventure-bot/
├── gradle.properties          ← NEU: Android-Konfiguration
├── build.gradle.kts           ← AKTUALISIERT: Dependencies korrigiert
├── settings.gradle.kts        ← AKTUALISIERT: Repository-Config
├── app/
│   ├── build.gradle.kts       ← App-spezifische Config
│   ├── src/
│   │   └── main/
│   │       ├── AndroidManifest.xml
│   │       ├── kotlin/        ← Dein Kotlin-Code
│   │       └── res/           ← Ressourcen (Layouts, Strings, etc.)
│   └── proguard-rules.pro
├── gradle/
│   └── wrapper/
│       └── gradle-wrapper.jar
├── .github/
│   └── workflows/
│       └── build-apk.yml
└── gradlew
```

**Wichtig:** Stelle sicher, dass dein `app/build.gradle.kts` auch aktualisiert ist!
