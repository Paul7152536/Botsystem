# EatAdventure Bot v4

## ✅ Änderungen in dieser Version

- ✅ `gradle.properties` mit `android.useAndroidX=true` hinzugefügt
- ✅ AccessibilityService auf neueste kompatible Version (1.1.0) aktualisiert
- ✅ Alle Dependencies aktualisiert auf stabile, verfügbare Versionen
- ✅ Java 17 konfiguriert
- ✅ Android compileSdk 33 gesetzt

## 🚀 So geht's:

1. **Lade diese ZIP auf GitHub hoch** (am besten unter `.github/workflows/` oder Repo-Root)
2. **Gehe zu Actions → Run workflow**
3. **Warte auf APK**
4. **Download und installieren!**

## 📋 Requirements

- Android 5.1+ (minSdk 21)
- Accessibility Service Berechtigung (beim Start aktivieren)

## ⚙️ Konfiguration

Alle wichtigen Einstellungen sind in:
- `gradle.properties` - Android-Konfiguration
- `app/build.gradle.kts` - Dependencies und SDK-Versionen
- `settings.gradle.kts` - Repository-Konfiguration

